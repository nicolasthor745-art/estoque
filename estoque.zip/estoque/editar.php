<?php

include("conexao.php");

$id = $_GET['id'];
$sql = "SELECT * FROM estoque WHERE id = $id";
$resultado = $mysqli->query($sql);
$item = $resultado->fetch_assoc();

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Item</title>
    <style>
        :root {
            --primary-dark: #2C3E50;
            --primary-orange: #E67E22;
            --bg-light: #ECF0F1;
            --border-gray: #BDC3C7;
            --white: #ffffff;
            --font: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            --input-bg: #f7f7f7;
            --shadow-soft: rgba(0,0,0,0.08);
        }

        body {
            background-color: var(--bg-light);
            font-family: var(--font);
            display: flex;
            justify-content: center;
            padding-top: 50px;
        }

        .form-card {
            background: var(--white);
            padding: 30px 35px;
            width: 380px;
            border-radius: 12px;
            border: 1px solid var(--border-gray);
            box-shadow: 0 6px 15px var(--shadow-soft);
            animation: fadeIn 0.4s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-card h2 {
            text-align: center;
            color: var(--primary-dark);
            margin-bottom: 20px;
            font-size: 22px;
        }

        label {
            font-weight: 600;
            color: var(--primary-dark);
            display: block;
            margin-bottom: 6px;
            margin-top: 12px;
            font-size: 14px;
        }

        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--border-gray);
            background: var(--input-bg);
            border-radius: 8px;
            font-size: 16px;
            outline: none;
            transition: 0.25s;
            box-sizing: border-box;
        }

        input[type="text"]:focus,
        input[type="number"]:focus {
            border-color: var(--primary-orange);
            background: white;
            box-shadow: 0 0 6px rgba(230, 109, 4, 0.4);
        }

        .btn-submit {
            margin-top: 25px;
            width: 100%;
            padding: 14px;
            background: var(--primary-orange);
            border: none;
            color: white;
            border-radius: 8px;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.25s ease;
        }

        .btn-submit:hover {
            background: rgb(147, 87, 3);
            transform: translateY(-3px);
            box-shadow: 0 4px 10px rgba(211, 84, 0, 0.3);
        }

        .btn-submit:active {
            transform: translateY(0);
            box-shadow: none;
        }
        </style>
</head>

<body>

    <form action="atualizar.php" method="POST" class="form-card">
        <h2>Editar Item</h2>
        <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo $item['nome']; ?>">
        <label>Quantidade:</label>
        <input type="number" name="quantidade" value="<?php echo $item['quantidade']; ?>">
        <label>Categoria:</label>
        <input type="text" name="categoria" value="<?php echo $item['categoria']; ?>">
        <button type="submit" class="btn-submit">Salvar alterações</button>
    </form>

</body>
</html>
