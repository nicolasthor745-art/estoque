<?php
include("conexao.php"); 
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Ferramentas</title>
    <style>
table {
    width: 80%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    margin-top: 20px;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}


th {
    background: #E67E22;
    color: white;
    padding: 14px;
    font-size: 16px;
    letter-spacing: 0.5px;
}


td {
    padding: 12px;
    border-bottom: 1px solid #ddd;
    font-size: 15px;
}


tr:nth-child(even) {
    background: #f7f7f7;
}


tr:hover {
    background: #ffe0bf;
}

/* Ações */
.actions a {
    padding: 8px 12px;
    background: #E67E22;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-weight: bold;
    transition: 0.2s;
    display: inline-block;
}

.actions a:hover {
    background: #c46a17;
    transform: translateY(-2px);
}

    </style>
</head>
<body>
    <h1>Lista de Ferramentas</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Quantidade</th>
            <th>Categoria</th>
            <th>Ações</th>
        </tr>
<?php
$sql = "SELECT * FROM estoque ORDER BY nome ASC";
$result = $mysqli->query($sql);
if ($result->num_rows > 0) {
    while ($linha = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $linha['id'] . "</td>";
        echo "<td>" . $linha['nome'] . "</td>";
        echo "<td>" . $linha['quantidade'] . "</td>";
        echo "<td>" . $linha['categoria'] . "</td>";
        echo "<td class='actions'>
        <a href='editar.php?id=" . $linha['id'] . "'>Editar</a>
        <a href='excluir.php?id=" . $linha['id'] . "' onclick=\"return confirm('Tem certeza que deseja excluir?');\">Excluir</a>
        </td>";
        echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='5'>Nenhuma ferramenta cadastrada</td></tr>";
        }
?>

    </table>

    <br><br>
    <a href="index.html">⬅ Voltar</a>

</body>
</html>
