<?php
include("conexao.php");

$id = $_GET['id'];
$sql = "DELETE FROM estoque WHERE id = $id";

if ($mysqli->query($sql) === TRUE) {
    echo " Item removido com sucesso!<br>";
    echo '<a href="listar.php">Voltar à lista</a>';
} else {
    echo " Erro ao excluir: " . $conn->error;
}

$mysqli->close();
?>
