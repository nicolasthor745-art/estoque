
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="style2.css">
</head>
<?php

include("conexao.php");

$nome = $_POST["nome"];
$quantidade = $_POST["number"];
$categoria = $_POST["categoria"];

if (empty($nome) || empty($quantidade) || empty($categoria)){
    die(' <div> <br> <e> Por favor, preencha todos os campos!</e> <br> <br>
    <a  href="index.html" class="botao1" >Voltar</a> </div>');
}

$sql = "INSERT INTO estoque (nome, quantidade, categoria)
    VALUES ('$nome', '$quantidade', '$categoria')";

if($mysqli->query($sql)){
    echo '<div>ferramenta salva com sucesso!
    <a href="listar.php" class="botao1" >ver lista</a> </div>';
}else{
    echo "erro ao salvar: " . $mysqli->error;
}

?>