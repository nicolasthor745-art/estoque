<?php
include("conexao.php");

$id = $_POST['id'];
$nome = $_POST['nome'];
$quantidade = $_POST['quantidade'];
$categoria = $_POST['categoria'];

$sql = "UPDATE estoque 
SET nome='$nome', quantidade='$quantidade', categoria='$categoria' 
WHERE id = $id";

if ($mysqli->query($sql)) {
    echo "Atualizado com sucesso!<br>";
    echo '<a href="listar.php">Voltar</a>';
} else {
    echo "Erro: " . $mysqli->error;
}
?>
